# AXStretchableHeaderTabViewController CHANGELOG

## 0.2.0

Feature: The KVO is available for selectedIndex and selectedViewController properties.

## 0.1.9

Feature: AXStretchableSubViewControllerViewSource protocol is available to set scroll view.

## 0.1.8

Feature: No swipable header is default. Look at "No horizontal swipe header" example.

## 0.1.7

Feature: Support "self" in interactive header view.

## 0.1.6

Feature: Reveal delegate in tab view controller.

## 0.1.5

Feature: add bottom separator.

## 0.1.4

Fix: Detect hit event in children/grandchildren of header view subviews.

## 0.1.3

Fix: View controller transition fault

## 0.1.2

Feature: No header view style.

## 0.1.1

Fix little bug in Example Files.

## 0.1.0

Initial release.
