//
//  AXTabBarItemButton.h
//  Pods
//

#import <UIKit/UIKit.h>

@interface AXTabBarItemButton : UIButton
@property (copy, nonatomic) NSString *badgeValue;
@end
