//
//  AXSub2TableViewController.h
//  StretchableHeaderTabViewExample
//

#import <UIKit/UIKit.h>

@interface AXSub2TableViewController : UITableViewController

@end
