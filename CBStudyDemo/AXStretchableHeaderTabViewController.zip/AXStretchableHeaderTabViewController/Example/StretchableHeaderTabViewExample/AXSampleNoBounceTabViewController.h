//
//  AXSampleNoBounceTabViewController.h
//  StretchableHeaderTabViewExample
//

#import "AXStretchableHeaderTabViewController.h"

@interface AXSampleNoBounceTabViewController : AXStretchableHeaderTabViewController

@end
