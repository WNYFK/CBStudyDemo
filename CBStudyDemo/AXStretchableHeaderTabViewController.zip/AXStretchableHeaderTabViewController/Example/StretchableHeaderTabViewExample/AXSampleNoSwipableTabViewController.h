//
//  AXSampleNoSwipableTabViewController.h
//  StretchableHeaderTabViewExample
//

#import "AXStretchableHeaderTabViewController.h"

@interface AXSampleNoSwipableTabViewController : AXStretchableHeaderTabViewController

@end
