//
//  AXAppDelegate.h
//  StretchableHeaderTabViewExample
//

#import <UIKit/UIKit.h>

@interface AXAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
