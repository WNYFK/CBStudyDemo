//
//  AXEmptyViewController.h
//  StretchableHeaderTabViewExample
//

#import <UIKit/UIKit.h>

@interface AXEmptyViewController : UIViewController

@end
