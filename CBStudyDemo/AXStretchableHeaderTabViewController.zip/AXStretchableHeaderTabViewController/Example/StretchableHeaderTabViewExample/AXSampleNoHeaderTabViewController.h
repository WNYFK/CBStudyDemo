//
//  AXSampleNoHeaderTabViewController.h
//  StretchableHeaderTabViewExample
//

#import "AXStretchableHeaderTabViewController.h"

@interface AXSampleNoHeaderTabViewController : AXStretchableHeaderTabViewController

@end
