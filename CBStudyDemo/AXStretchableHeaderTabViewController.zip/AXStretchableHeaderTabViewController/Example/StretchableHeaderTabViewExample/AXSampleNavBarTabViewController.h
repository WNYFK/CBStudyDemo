//
//  AXSampleNavBarTabViewController.h
//  StretchableHeaderTabViewExample
//

#import "AXStretchableHeaderTabViewController.h"

@interface AXSampleNavBarTabViewController : AXStretchableHeaderTabViewController

@end
