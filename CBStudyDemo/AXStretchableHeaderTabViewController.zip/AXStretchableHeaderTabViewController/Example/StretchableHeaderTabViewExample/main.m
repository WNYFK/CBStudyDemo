//
//  main.m
//  StretchableHeaderTabViewExample
//
//  Created by Hiroki Akiyama on 2014/05/25.
//  Copyright (c) 2014年 Hiroki Akiyama. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AXAppDelegate.h"

int main(int argc, char * argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([AXAppDelegate class]));
  }
}
