//
//  AXSub3ViewController.h
//  StretchableHeaderTabViewExample
//

#import <UIKit/UIKit.h>

@interface AXSub3ViewController : UIViewController
@property (readonly, nonatomic) UILabel *sampleLabel;
@end
