//
//  AXSampleNoSwipableHeaderView.h
//  StretchableHeaderTabViewExample
//

#import "AXStretchableHeaderView.h"

@interface AXSampleNoSwipableHeaderView : AXStretchableHeaderView

@end
