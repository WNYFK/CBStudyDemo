//
//  AXSampleTabViewController.h
//  StretchableHeaderTabViewExample
//

#import <AXStretchableHeaderTabViewController/AXStretchableHeaderTabViewController.h>

@interface AXSampleTabViewController : AXStretchableHeaderTabViewController

@end
